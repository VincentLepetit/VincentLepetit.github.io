# /bin/sh


main_tex_file=(`grep -l documentclass *tex 2> /dev/null`)

pptx_file=(`basename $main_tex_file .tex`_pptx.pptx)
pptx_pdf_file=(`basename $main_tex_file .tex`_pptx.pdf)

dir_pptx_pdf_file=(`pwd`/$pptx_pdf_file)

echo $dir_pptx_pdf_file

echo "> Saving $pptx_file file to pdf:"
osascript ~/bin/convert_images_pptx_to_images_pdf.scpt $dir_pptx_pdf_file

mkdir images >& /dev/null
echo "> Extracting the images from the pdf file: pdftk $pptx_pdf_file burst output images/fig_%03d.pdf"
pdftk $pptx_pdf_file burst output images/fig_%03d.pdf
